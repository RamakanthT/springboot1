package com.example.demo2.controller;

import org.springframework.stereotype.Controller;

@Controller
public class LoginController {

}
